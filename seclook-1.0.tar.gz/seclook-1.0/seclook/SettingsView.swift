//
//  SettingsView.swift
//  seclook
//
//  Created by Andrew Katz on 11/17/23.
//


import SwiftUI

struct SettingsView: View {
    var body: some View {
        // Define your settings UI here
        Text("Settings")
    }
}
